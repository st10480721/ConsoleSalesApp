package com.mycompany.hospitalpatientadmissionsystem;

import hospital.ui.HospitalUI;

public class HospitalPatientAdmissionSystem {
    public static void main(String[] args) {
        System.out.println("=== Welcome to MediCare Hospital Patient Admission System ===\n");
        
       
        HospitalUI ui = new HospitalUI();
        ui.start();
    }
}