package hospital.ui;

import hospital.model.*;
import hospital.service.*;
import java.util.*;

public class HospitalUI {
    private PatientService patientService;
    private BedManager bedManager;
    private Scanner scanner;
    
    public HospitalUI() {
        this.bedManager = new BedManager();
        this.patientService = new PatientService(bedManager);
        this.scanner = new Scanner(System.in);
    }
    
    public void start() {
        while (true) {
            displayMainMenu();
            int choice = getIntInput("Enter your choice: ");
            
            switch (choice) {
                case 1:
                    registerPatient();
                    break;
                case 2:
                    searchPatient();
                    break;
                case 3:
                    updatePatient();
                    break;
                case 4:
                    deletePatient();
                    break;
                case 5:
                    displayAllPatients();
                    break;
                case 6:
                    allocateBed();
                    break;
                case 7:
                    releaseBed();
                    break;
                case 8:
                    displayWardInfo();
                    break;
                case 9:
                    generateReports();
                    break;
                case 0:
                    System.out.println("Exiting system... Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
    
    private void displayMainMenu() {
        System.out.println("\n=== Hospital Patient Admission System ===");
        System.out.println("1. Register Patient");
        System.out.println("2. Search Patient");
        System.out.println("3. Update Patient");
        System.out.println("4. Delete Patient");
        System.out.println("5. Display All Patients");
        System.out.println("6. Allocate Bed");
        System.out.println("7. Release Bed");
        System.out.println("8. Display Ward Information");
        System.out.println("9. Generate Reports");
        System.out.println("0. Exit");
    }
    
    // FIXED: Generate Reports with auto-continue
    private void generateReports() {
        while (true) {
            System.out.println("\n╔════════════════════════════════════════════════╗");
            System.out.println("║              GENERATE REPORTS                   ║");
            System.out.println("╠════════════════════════════════════════════════╣");
            System.out.println("║  1. Display all patients                        ║");
            System.out.println("║  2. Display available beds                      ║");
            System.out.println("║  3. Display occupied beds                       ║");
            System.out.println("║  4. Display total registered patients           ║");
            System.out.println("║  5. Display total occupied beds                 ║");
            System.out.println("║  6. Display ward occupancy percentage           ║");
            System.out.println("║  7. Sort patients by surname                    ║");
            System.out.println("║  8. Sort patients by ID                         ║");
            System.out.println("║  0. Back to Main Menu                           ║");
            System.out.println("╚════════════════════════════════════════════════╝");
            
            int choice = getIntInput("Enter your choice: ");
            
            switch (choice) {
                case 1:
                    System.out.println("\n--- All Registered Patients ---");
                    patientService.displayAllPatients();
                    break;
                case 2:
                    System.out.println("\n--- Available Beds ---");
                    bedManager.displayAvailableBeds();
                    break;
                case 3:
                    System.out.println("\n--- Occupied Beds ---");
                    bedManager.displayOccupiedBeds();
                    break;
                case 4:
                    System.out.println("\n--- Total Registered Patients ---");
                    System.out.println("Total Patients: " + patientService.getTotalPatients());
                    break;
                case 5:
                    System.out.println("\n--- Total Occupied Beds ---");
                    System.out.println("Occupied Beds: " + bedManager.getOccupiedBedCount() + " / " + bedManager.getTotalBeds());
                    break;
                case 6:
                    System.out.println("\n--- Ward Occupancy Percentage ---");
                    System.out.printf("Occupancy: %.1f%%\n", bedManager.getOccupancyPercentage());
                    System.out.println("(" + bedManager.getOccupiedBedCount() + " of " + bedManager.getTotalBeds() + " beds occupied)");
                    break;
                case 7:
                    System.out.println("\n--- Patients Sorted by Surname ---");
                    List<Patient> sortedBySurname = patientService.sortPatientsBySurname();
                    if (sortedBySurname.isEmpty()) {
                        System.out.println("No patients registered.");
                    } else {
                        System.out.println("ID\tName\t\tCategory");
                        System.out.println("----------------------------------------");
                        for (Patient p : sortedBySurname) {
                            System.out.printf("%s\t%s %s\t%s%n", 
                                p.getPatientId(), 
                                p.getFirstName(), 
                                p.getLastName(), 
                                p.getCategory());
                        }
                    }
                    break;
                case 8:
                    System.out.println("\n--- Patients Sorted by ID ---");
                    List<Patient> sortedById = patientService.sortPatientsById();
                    if (sortedById.isEmpty()) {
                        System.out.println("No patients registered.");
                    } else {
                        System.out.println("ID\tName\t\tCategory");
                        System.out.println("----------------------------------------");
                        for (Patient p : sortedById) {
                            System.out.printf("%s\t%s %s\t%s%n", 
                                p.getPatientId(), 
                                p.getFirstName(), 
                                p.getLastName(), 
                                p.getCategory());
                        }
                    }
                    break;
                case 0:
                    System.out.println("Returning to main menu...");
                    return;
                default:
                    System.out.println("Invalid choice! Please enter a number between 0 and 8.");
            }
            
            // FIXED: Auto-continue without Enter key
            if (choice != 0) {
                System.out.println("\n----------------------------------------");
                System.out.println("Returning to reports menu in 3 seconds...");
                try {
                    Thread.sleep(3000);  // Wait 3 seconds
                } catch (InterruptedException e) {
                    // Ignore
                }
            }
        }
    }
    
    // ============================================================
    // All other methods remain the same...
    // ============================================================
    
    private void registerPatient() {
        System.out.println("\n=== Register New Patient ===");
        
        String patientId = getStringInput("Enter Patient ID: ");
        if (patientService.patientExists(patientId)) {
            System.out.println("Error: Patient ID already exists!");
            return;
        }
        
        String firstName = getStringInput("Enter First Name: ");
        String lastName = getStringInput("Enter Last Name: ");
        int age = getIntInput("Enter Age: ");
        String gender = getStringInput("Enter Gender (M/F): ");
        String medicalCondition = getStringInput("Enter Medical Condition: ");
        
        System.out.println("Select Patient Category:");
        System.out.println("1. Inpatient");
        System.out.println("2. Outpatient");
        System.out.println("3. Emergency");
        int categoryChoice = getIntInput("Enter choice: ");
        
        Patient patient;
        PatientCategory category;
        
        switch (categoryChoice) {
            case 1:
                category = PatientCategory.INPATIENT;
                int wardNumber = 1;
                // Try to allocate a bed
                String bedNumber = bedManager.allocateBed(null);
                if (bedNumber == null) {
                    System.out.println("Error: No beds available!");
                    return;
                }
                patient = new Inpatient(patientId, firstName, lastName, age, gender, 
                                       medicalCondition, wardNumber, bedNumber);
                break;
            case 2:
                category = PatientCategory.OUTPATIENT;
                patient = new Patient(patientId, firstName, lastName, age, gender, 
                                     medicalCondition, category);
                break;
            case 3:
                category = PatientCategory.EMERGENCY;
                patient = new Patient(patientId, firstName, lastName, age, gender, 
                                     medicalCondition, category);
                break;
            default:
                System.out.println("Invalid category!");
                return;
        }
        
        // For inpatients, properly allocate the bed
        if (category == PatientCategory.INPATIENT) {
            Inpatient inpatient = (Inpatient) patient;
            String bedNum = bedManager.allocateBed(inpatient);
            if (bedNum == null) {
                System.out.println("Error: No beds available!");
                return;
            }
            inpatient.setBedNumber(bedNum);
            patient = inpatient;
        }
        
        patientService.registerPatient(patient);
    }
    
    private void searchPatient() {
        System.out.println("\n=== Search Patient ===");
        String patientId = getStringInput("Enter Patient ID to search: ");
        Patient patient = patientService.searchPatient(patientId);
        
        if (patient == null) {
            System.out.println("Patient not found!");
        } else {
            System.out.println("\n--- Patient Details ---");
            patient.displayDetails();
        }
    }
    
    private void updatePatient() {
        System.out.println("\n=== Update Patient ===");
        String patientId = getStringInput("Enter Patient ID to update: ");
        Patient existing = patientService.searchPatient(patientId);
        
        if (existing == null) {
            System.out.println("Patient not found!");
            return;
        }
        
        System.out.println("Enter new details (leave blank to keep current):");
        String firstName = getStringInputOptional("First Name [" + existing.getFirstName() + "]: ");
        String lastName = getStringInputOptional("Last Name [" + existing.getLastName() + "]: ");
        String ageStr = getStringInputOptional("Age [" + existing.getAge() + "]: ");
        String gender = getStringInputOptional("Gender [" + existing.getGender() + "]: ");
        String medicalCondition = getStringInputOptional("Medical Condition [" + existing.getMedicalCondition() + "]: ");
        
        firstName = firstName.isEmpty() ? existing.getFirstName() : firstName;
        lastName = lastName.isEmpty() ? existing.getLastName() : lastName;
        int age = ageStr.isEmpty() ? existing.getAge() : Integer.parseInt(ageStr);
        gender = gender.isEmpty() ? existing.getGender() : gender;
        medicalCondition = medicalCondition.isEmpty() ? existing.getMedicalCondition() : medicalCondition;
        
        Patient updatedPatient;
        if (existing instanceof Inpatient) {
            Inpatient inpatient = (Inpatient) existing;
            updatedPatient = new Inpatient(patientId, firstName, lastName, age, gender,
                                          medicalCondition, inpatient.getWardNumber(), 
                                          inpatient.getBedNumber());
        } else {
            updatedPatient = new Patient(patientId, firstName, lastName, age, gender,
                                        medicalCondition, existing.getCategory());
        }
        
        patientService.updatePatient(patientId, updatedPatient);
    }
    
    private void deletePatient() {
        System.out.println("\n=== Delete Patient ===");
        String patientId = getStringInput("Enter Patient ID to delete: ");
        patientService.deletePatient(patientId);
    }
    
    private void displayAllPatients() {
        patientService.displayAllPatients();
    }
    
    private void allocateBed() {
        System.out.println("\n=== Allocate Bed ===");
        String patientId = getStringInput("Enter Inpatient ID: ");
        Patient patient = patientService.searchPatient(patientId);
        
        if (patient == null) {
            System.out.println("Patient not found!");
            return;
        }
        
        if (!(patient instanceof Inpatient)) {
            System.out.println("Patient is not an inpatient!");
            return;
        }
        
        Inpatient inpatient = (Inpatient) patient;
        if (inpatient.getBedNumber() != null && !inpatient.getBedNumber().isEmpty()) {
            System.out.println("Patient already has a bed: " + inpatient.getBedNumber());
            return;
        }
        
        String bedNumber = bedManager.allocateBed(inpatient);
        if (bedNumber == null) {
            System.out.println("No beds available!");
        } else {
            inpatient.setBedNumber(bedNumber);
            System.out.println("Bed " + bedNumber + " allocated successfully!");
        }
    }
    
    private void releaseBed() {
        System.out.println("\n=== Release Bed ===");
        String bedNumber = getStringInput("Enter Bed Number to release (e.g., B01): ");
        bedManager.releaseBed(bedNumber);
    }
    
    private void displayWardInfo() {
        System.out.println("\n=== Ward Information ===");
        bedManager.displayWardLayout();
        System.out.println("\nAvailable Beds: " + bedManager.getAvailableBedCount());
        System.out.println("Occupied Beds: " + bedManager.getOccupiedBedCount());
        System.out.printf("Occupancy Rate: %.1f%%\n", bedManager.getOccupancyPercentage());
    }
    
    private String getStringInput(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }
    
    private String getStringInputOptional(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }
    
    private int getIntInput(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}