package hospital.service;

import hospital.model.*;
import java.util.*;

public class BedManager {
    private Map<String, Bed> beds;
    private int totalBeds = 20;
    private final int ROWS = 4;
    private final int COLS = 5;
    
    public BedManager() {
        beds = new HashMap<>();
        initializeBeds();
    }
    
    private void initializeBeds() {
        int bedNum = 1;
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                String bedId = String.format("B%02d", bedNum);
                beds.put(bedId, new Bed(bedId));
                bedNum++;
            }
        }
    }
    
    // Allocate bed to inpatient
    public String allocateBed(Inpatient patient) {
        for (Bed bed : beds.values()) {
            if (!bed.isOccupied()) {
                bed.assignPatient(patient);
                // Set the bed number in the inpatient object
                // Note: You'll need to add a setter for bedNumber in Inpatient
                return bed.getBedNumber();
            }
        }
        return null; // No beds available
    }
    
    // Release bed
    public boolean releaseBed(String bedNumber) {
        Bed bed = beds.get(bedNumber);
        if (bed == null) {
            System.out.println("Error: Bed not found!");
            return false;
        }
        if (!bed.isOccupied()) {
            System.out.println("Error: Bed is already available!");
            return false;
        }
        bed.releasePatient();
        System.out.println("Bed " + bedNumber + " released successfully!");
        return true;
    }
    
    // Display ward layout (4x5 grid)
    public void displayWardLayout() {
        System.out.println("\n=== Ward Layout (4x5) ===");
        int count = 0;
        for (Bed bed : beds.values()) {
            String status = bed.isOccupied() ? "[O]" : "[ ]";
            System.out.print(bed.getBedNumber() + status + "\t");
            count++;
            if (count % COLS == 0) {
                System.out.println();
            }
        }
    }
    
    // Display available beds
    public void displayAvailableBeds() {
        System.out.println("\n=== Available Beds ===");
        boolean found = false;
        for (Bed bed : beds.values()) {
            if (!bed.isOccupied()) {
                System.out.println(bed.getBedNumber());
                found = true;
            }
        }
        if (!found) {
            System.out.println("No available beds.");
        }
    }
    
    // Display occupied beds
    public void displayOccupiedBeds() {
        System.out.println("\n=== Occupied Beds ===");
        boolean found = false;
        for (Bed bed : beds.values()) {
            if (bed.isOccupied()) {
                System.out.println(bed);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No occupied beds.");
        }
    }
    
    // Get occupied bed count
    public int getOccupiedBedCount() {
        int count = 0;
        for (Bed bed : beds.values()) {
            if (bed.isOccupied()) count++;
        }
        return count;
    }
    
    // Get available bed count
    public int getAvailableBedCount() {
        return totalBeds - getOccupiedBedCount();
    }
    
    // Get occupancy percentage
    public double getOccupancyPercentage() {
        return (double) getOccupiedBedCount() / totalBeds * 100;
    }
    
    // Check if bed is occupied
    public boolean isBedOccupied(String bedNumber) {
        Bed bed = beds.get(bedNumber);
        return bed != null && bed.isOccupied();
    }
    
    public Bed getBed(String bedNumber) {
        return beds.get(bedNumber);
    }
    
    public int getTotalBeds() {
        return totalBeds;
    }
}