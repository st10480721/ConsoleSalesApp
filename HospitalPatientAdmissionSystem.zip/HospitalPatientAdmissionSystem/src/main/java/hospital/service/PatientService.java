package hospital.service;

import hospital.model.*;
import java.util.*;

public class PatientService {
    private Map<String, Patient> patients;
    private BedManager bedManager;
    
    public PatientService(BedManager bedManager) {
        this.patients = new HashMap<>();
        this.bedManager = bedManager;
    }
    
    // Register a new patient
    public boolean registerPatient(Patient patient) {
        if (patients.containsKey(patient.getPatientId())) {
            System.out.println("Error: Patient ID already exists!");
            return false;
        }
        
        // If inpatient, allocate bed
        if (patient instanceof Inpatient) {
            Inpatient inpatient = (Inpatient) patient;
            String bedNumber = bedManager.allocateBed(inpatient);
            if (bedNumber == null) {
                System.out.println("Error: No beds available for inpatient!");
                return false;
            }
            // BedManager already sets the bed number
        }
        
        patients.put(patient.getPatientId(), patient);
        System.out.println("Patient registered successfully!");
        return true;
    }
    
    // Search for patient by ID
    public Patient searchPatient(String patientId) {
        return patients.get(patientId);
    }
    
    // Update patient details
    public boolean updatePatient(String patientId, Patient updatedPatient) {
        if (!patients.containsKey(patientId)) {
            System.out.println("Error: Patient not found!");
            return false;
        }
        
        patients.put(patientId, updatedPatient);
        System.out.println("Patient updated successfully!");
        return true;
    }
    
    // Delete patient
    public boolean deletePatient(String patientId) {
        Patient patient = patients.remove(patientId);
        if (patient == null) {
            System.out.println("Error: Patient not found!");
            return false;
        }
        
        // If inpatient, release bed
        if (patient instanceof Inpatient) {
            Inpatient inpatient = (Inpatient) patient;
            bedManager.releaseBed(inpatient.getBedNumber());
        }
        
        System.out.println("Patient deleted successfully!");
        return true;
    }
    
    // Display all patients
    public void displayAllPatients() {
        if (patients.isEmpty()) {
            System.out.println("No patients registered.");
            return;
        }
        
        System.out.println("\n=== All Registered Patients ===");
        for (Patient p : patients.values()) {
            p.displayDetails();
            System.out.println("------------------------");
        }
    }
    
    // Get total patients count
    public int getTotalPatients() {
        return patients.size();
    }
    
    // Get all patients as list
    public List<Patient> getAllPatients() {
        return new ArrayList<>(patients.values());
    }
    
    // Sort patients by surname
    public List<Patient> sortPatientsBySurname() {
        List<Patient> sorted = new ArrayList<>(patients.values());
        sorted.sort(Comparator.comparing(Patient::getLastName));
        return sorted;
    }
    
    // Sort patients by ID
    public List<Patient> sortPatientsById() {
        List<Patient> sorted = new ArrayList<>(patients.values());
        sorted.sort(Comparator.comparing(Patient::getPatientId));
        return sorted;
    }
    
    public boolean patientExists(String patientId) {
        return patients.containsKey(patientId);
    }
}