package hospital.model;

public class Bed {
    private String bedNumber;
    private boolean occupied;
    private Inpatient assignedPatient;
    
    public Bed(String bedNumber) {
        this.bedNumber = bedNumber;
        this.occupied = false;
        this.assignedPatient = null;
    }
    
    public String getBedNumber() { return bedNumber; }
    public boolean isOccupied() { return occupied; }
    public Inpatient getAssignedPatient() { return assignedPatient; }
    
    public void assignPatient(Inpatient patient) {
        this.assignedPatient = patient;
        this.occupied = true;
    }
    
    public void releasePatient() {
        this.assignedPatient = null;
        this.occupied = false;
    }
    
    @Override
    public String toString() {
        String status = occupied ? "OCCUPIED" : "AVAILABLE";
        String patientInfo = occupied ? " - " + assignedPatient.getFirstName() + " " + assignedPatient.getLastName() : "";
        return bedNumber + ": " + status + patientInfo;
    }
}