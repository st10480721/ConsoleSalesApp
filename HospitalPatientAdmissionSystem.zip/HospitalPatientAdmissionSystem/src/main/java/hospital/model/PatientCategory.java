package hospital.model;

public enum PatientCategory {
    INPATIENT,
    OUTPATIENT,
    EMERGENCY
}